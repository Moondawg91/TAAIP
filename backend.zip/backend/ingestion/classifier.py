"""
Simple ingestion classifier + header detection utilities.
This is a lightweight rules-first classifier for USAREC dataset types.
"""
from typing import List, Dict, Any, Optional
import csv
import re
import json

def detect_header_csv(path: str, max_rows: int = 60) -> Optional[int]:
    with open(path, newline='') as f:
        reader = csv.reader(f)
        rows = []
        for i, row in enumerate(reader):
            rows.append(row)
            if i >= max_rows - 1:
                break
    for i, row in enumerate(rows[:25]):
        nonempty = sum(1 for v in row if v and str(v).strip())
        if nonempty >= 4:
            return i
    return None

def normalize_col(c: Any) -> str:
    if c is None:
        return ''
    s = str(c).strip().lower()
    s = re.sub(r"\s+", " ", s)
    return s

def classify_columns(cols: List[str]) -> Dict[str, Any]:
    """Return a simple classification dict with dataset_type and score."""
    colset = set(cols)
    def any_in(opts):
        return any(o in colset for o in opts)

    dataset = 'unknown'
    if any_in(['zip', 'zip code', 'zipcode']) and any_in(['share', 'market share']) and any_in(['contr', 'contracts', 'contract']):
        dataset = 'market_share_contracts'
    elif any_in(['zip', 'zip code', 'zipcode']) and any_in(['category', 'cat']):
        dataset = 'zip_by_category'
    elif any_in(['rsid', 'stn', 'stn', 'station']) and any_in(['act', 'res', 'vol', 'volume']):
        dataset = 'station_volume'

    # determine grain
    grain = None
    if any_in(['rsid', 'stn', 'station']):
        grain = 'STN'
    elif any_in(['bn', 'battalion']):
        grain = 'BN'
    elif any_in(['zip', 'zipcode']):
        grain = 'ZIP'

    return {
        'dataset_type': dataset,
        'grain': grain,
        'columns': cols,
        'confidence': 0.9 if dataset != 'unknown' else 0.3,
    }

def inspect_csv(path: str) -> Dict[str, Any]:
    header_row = detect_header_csv(path)
    # read header using csv when header_row found
    header = []
    if header_row is not None:
        with open(path, newline='') as f:
            reader = csv.reader(f)
            for i, row in enumerate(reader):
                if i == header_row:
                    header = [normalize_col(c) for c in row]
                    break
    return {
        'header_row': header_row,
        'columns': header,
        'classification': classify_columns(header)
    }
